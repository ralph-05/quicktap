"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { signInWithEmailAndPassword } from "firebase/auth"
import { getFirebaseAuth } from "@/lib/firebase"
import Link from "next/link"
import "../auth.css"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState("guest")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const auth = getFirebaseAuth()
      if (!auth) {
        setError("Authentication service not available")
        setLoading(false)
        return
      }

      await signInWithEmailAndPassword(auth, email, password)

      // Store role in localStorage
      localStorage.setItem("userRole", role)

      // Redirect based on role
      if (role === "admin") {
        router.push("/dashboard")
      } else if (role === "cashier") {
        router.push("/cashier")
      } else {
        router.push("/menu")
      }
    } catch (err: any) {
      setError(err.message || "Failed to login")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-container">
      <div className="auth-card">
        <h1 className="auth-title">Tori Cafeteria</h1>
        <h2 className="auth-subtitle">LOGIN</h2>

        {error && <div className="auth-error">{error}</div>}

        <form onSubmit={handleLogin} className="auth-form">
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              className="form-input"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Login As</label>
            <select className="form-input" value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="guest">Guest (Customer)</option>
              <option value="cashier">Cashier</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          <button type="submit" className="auth-button" disabled={loading}>
            {loading ? "LOGGING IN..." : "LOGIN"}
          </button>
        </form>

        <div className="auth-footer">
          <p>Don't have an account?</p>
          <Link href="/auth/signup" className="auth-link">
            Sign up here
          </Link>
        </div>
      </div>
    </div>
  )
}
