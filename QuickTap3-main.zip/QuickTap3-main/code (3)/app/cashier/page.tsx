"use client"

import { ProtectedRoute } from "@/components/protected-route"
import { useState } from "react"

export default function CashierPage() {
  const [orders, setOrders] = useState([])

  return (
    <ProtectedRoute requiredRole="cashier">
      <div className="admin-dashboard">
        <header className="admin-header">
          <h1>CASHIER DASHBOARD</h1>
        </header>

        <div style={{ padding: "40px", textAlign: "center" }}>
          <h2 style={{ color: "#8B7355", marginBottom: "20px" }}>Sales Management</h2>
          <p style={{ fontSize: "18px", color: "#666" }}>
            Coming soon: Order management, sales tracking, and payment processing
          </p>
        </div>
      </div>
    </ProtectedRoute>
  )
}
