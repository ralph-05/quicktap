import Link from "next/link"

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="text-center space-y-8">
        <h1 className="text-5xl font-bold text-amber-900">Tori Cafeteria</h1>
        <p className="text-xl text-amber-700">Welcome to Our Cafeteria Management System</p>

        <div className="flex flex-col gap-4 mt-8">
          <Link
            href="/auth/login"
            className="px-8 py-3 bg-amber-800 text-white rounded-lg font-semibold hover:bg-amber-900 transition"
          >
            Login
          </Link>
          <Link
            href="/auth/signup"
            className="px-8 py-3 bg-amber-600 text-white rounded-lg font-semibold hover:bg-amber-700 transition"
          >
            Sign Up
          </Link>
        </div>

        <div className="mt-12 space-y-4 max-w-md">
          <h2 className="text-lg font-semibold text-amber-900">Available Roles:</h2>
          <ul className="text-left text-amber-800 space-y-2">
            <li>
              ✓ <strong>Admin:</strong> Manage menu, drinks, bookings, and trends
            </li>
            <li>
              ✓ <strong>Cashier:</strong> Process orders and manage sales
            </li>
            <li>
              ✓ <strong>Guest:</strong> View menu and place orders
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
