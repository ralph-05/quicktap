import Link from "next/link"

export default function UnauthorizedPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-red-600">Access Denied</h1>
        <p className="text-lg text-gray-600">You don't have permission to access this page.</p>
        <Link
          href="/auth/login"
          className="px-6 py-2 bg-amber-800 text-white rounded-lg font-semibold hover:bg-amber-900 transition mt-4"
        >
          Back to Login
        </Link>
      </div>
    </div>
  )
}
