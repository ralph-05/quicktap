"use client"

import { useState, useEffect } from "react"
import "./admin-dashboard.css"
import { getFirebaseDb } from "@/lib/firebase"
import { collection, onSnapshot, query, addDoc, updateDoc, deleteDoc, doc } from "firebase/firestore"

export default function AdminDashboard() {
  const [currentView, setCurrentView] = useState("menu")
  const [menuItems, setMenuItems] = useState([])
  const [bookings, setBookings] = useState([])
  const [trendData, setTrendData] = useState([])
  const [drinkWheelItems, setDrinkWheelItems] = useState([])
  const [selectedItem, setSelectedItem] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [showAddMenu, setShowAddMenu] = useState(false)
  const [newMenuItem, setNewMenuItem] = useState({ name: "", price: "", description: "", category: "COFFEE" })
  const [showAddDrink, setShowAddDrink] = useState(false)
  const [newDrink, setNewDrink] = useState("")

  useEffect(() => {
    const db = getFirebaseDb()

    if (!db) {
      setError("Firebase not initialized. Check your environment variables.")
      setLoading(false)
      console.log("[v0] Firebase DB is null, using demo data")
      return
    }

    try {
      // Fetch menu items
      const menuQuery = query(collection(db, "menuItems"))
      const unsubscribeMenu = onSnapshot(
        menuQuery,
        (snapshot) => {
          const items = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }))
          setMenuItems(items)
          setLoading(false)
        },
        (error) => {
          console.error("[v0] Menu fetch error:", error)
          setError(error.message)
          setLoading(false)
        },
      )

      // Fetch bookings
      const bookingsQuery = query(collection(db, "bookings"))
      const unsubscribeBookings = onSnapshot(
        bookingsQuery,
        (snapshot) => {
          const bookingsData = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }))
          setBookings(bookingsData)
        },
        (error) => {
          console.error("[v0] Bookings fetch error:", error)
        },
      )

      // Fetch trend data
      const trendQuery = query(collection(db, "trends"))
      const unsubscribeTrend = onSnapshot(
        trendQuery,
        (snapshot) => {
          const trends = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }))
          const sorted = trends.sort((a, b) => (b.unitSales || 0) - (a.unitSales || 0))
          setTrendData(sorted)
        },
        (error) => {
          console.error("[v0] Trends fetch error:", error)
        },
      )

      const drinkWheelQuery = query(collection(db, "drinkWheel"))
      const unsubscribeDrinkWheel = onSnapshot(
        drinkWheelQuery,
        (snapshot) => {
          const drinks = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }))
          setDrinkWheelItems(drinks)
        },
        (error) => {
          console.error("[v0] Drink wheel fetch error:", error)
        },
      )

      return () => {
        unsubscribeMenu()
        unsubscribeBookings()
        unsubscribeTrend()
        unsubscribeDrinkWheel()
      }
    } catch (err) {
      console.error("[v0] Firebase setup error:", err)
      setError(err.message)
      setLoading(false)
    }
  }, [])

  const handleAddMenuItem = async () => {
    if (!newMenuItem.name || !newMenuItem.price) {
      alert("Please fill in name and price")
      return
    }

    try {
      const db = getFirebaseDb()
      if (db) {
        await addDoc(collection(db, "menuItems"), {
          name: newMenuItem.name,
          price: Number.parseFloat(newMenuItem.price),
          description: newMenuItem.description,
          category: newMenuItem.category,
          image: "/placeholder.svg",
          createdAt: new Date(),
        })
        setNewMenuItem({ name: "", price: "", description: "", category: "COFFEE" })
        setShowAddMenu(false)
      }
    } catch (err) {
      console.error("[v0] Error adding menu item:", err)
      alert("Failed to add menu item")
    }
  }

  const handleDeleteMenuItem = async (itemId) => {
    try {
      const db = getFirebaseDb()
      if (db) {
        await deleteDoc(doc(db, "menuItems", itemId))
      }
    } catch (err) {
      console.error("[v0] Error deleting menu item:", err)
    }
  }

  const handleAddDrinkWheel = async () => {
    if (!newDrink.trim()) {
      alert("Please enter a drink name")
      return
    }

    try {
      const db = getFirebaseDb()
      if (db) {
        await addDoc(collection(db, "drinkWheel"), {
          name: newDrink,
          createdAt: new Date(),
        })
        setNewDrink("")
        setShowAddDrink(false)
      }
    } catch (err) {
      console.error("[v0] Error adding drink:", err)
      alert("Failed to add drink")
    }
  }

  const handleRemoveDrink = async (drinkId) => {
    try {
      const db = getFirebaseDb()
      if (db) {
        await deleteDoc(doc(db, "drinkWheel", drinkId))
      }
    } catch (err) {
      console.error("[v0] Error removing drink:", err)
    }
  }

  const handleApproveBooking = async (bookingId) => {
    try {
      const db = getFirebaseDb()
      if (db) {
        await updateDoc(doc(db, "bookings", bookingId), {
          status: "approved",
        })
      }
    } catch (err) {
      console.error("[v0] Error approving booking:", err)
    }
  }

  const handleCancelBooking = async (bookingId) => {
    try {
      const db = getFirebaseDb()
      if (db) {
        await deleteDoc(doc(db, "bookings", bookingId))
      }
    } catch (err) {
      console.error("[v0] Error canceling booking:", err)
    }
  }

  return (
    <div className="admin-dashboard">
      {error && (
        <div className="error-banner">
          <p>Firebase Error: {error}</p>
          <p className="error-hint">Make sure your Firestore collections are set up: menuItems, bookings, trends</p>
        </div>
      )}

      <header className="admin-header">
        <h1>ADMIN DASHBOARD</h1>
        <button className="menu-toggle">☰</button>
      </header>

      <div className="dashboard-container">
        <aside className="admin-sidebar">
          <nav className="sidebar-nav">
            <button
              className={`nav-button ${currentView === "menu" ? "active" : ""}`}
              onClick={() => setCurrentView("menu")}
            >
              EDIT MENU
            </button>
            <button
              className={`nav-button ${currentView === "drinkWheel" ? "active" : ""}`}
              onClick={() => setCurrentView("drinkWheel")}
            >
              EDIT DRINK WHEEL
            </button>
            <button
              className={`nav-button ${currentView === "trend" ? "active" : ""}`}
              onClick={() => setCurrentView("trend")}
            >
              CHECK DRINK TREND
            </button>
            <button
              className={`nav-button ${currentView === "bookings" ? "active" : ""}`}
              onClick={() => setCurrentView("bookings")}
            >
              CUSTOMER BOOKINGS
            </button>
            <button
              className={`nav-button ${currentView === "trending" ? "active" : ""}`}
              onClick={() => setCurrentView("trending")}
            >
              TRENDING PRODUCTS
            </button>
          </nav>
        </aside>

        <main className="admin-main">
          {/* Menu View */}
          {currentView === "menu" && (
            <section className="view-section">
              <div className="menu-header">
                <div className="category-tabs">
                  <button className="category-tab active">ALL</button>
                  <button className="category-tab">COFFEE</button>
                  <button className="category-tab">PASTRY</button>
                </div>
                <button className="action-btn add" onClick={() => setShowAddMenu(true)}>
                  + ADD MENU
                </button>
              </div>

              {showAddMenu && (
                <div className="add-menu-form">
                  <h3>Add New Menu Item</h3>
                  <input
                    type="text"
                    placeholder="Item Name"
                    className="form-input"
                    value={newMenuItem.name}
                    onChange={(e) => setNewMenuItem({ ...newMenuItem, name: e.target.value })}
                  />
                  <input
                    type="number"
                    placeholder="Price"
                    className="form-input"
                    value={newMenuItem.price}
                    onChange={(e) => setNewMenuItem({ ...newMenuItem, price: e.target.value })}
                  />
                  <input
                    type="text"
                    placeholder="Description"
                    className="form-input"
                    value={newMenuItem.description}
                    onChange={(e) => setNewMenuItem({ ...newMenuItem, description: e.target.value })}
                  />
                  <select
                    className="form-input"
                    value={newMenuItem.category}
                    onChange={(e) => setNewMenuItem({ ...newMenuItem, category: e.target.value })}
                  >
                    <option>COFFEE</option>
                    <option>PASTRY</option>
                    <option>BEVERAGE</option>
                  </select>
                  <div className="form-actions">
                    <button className="action-btn done" onClick={handleAddMenuItem}>
                      ADD
                    </button>
                    <button className="action-btn cancel" onClick={() => setShowAddMenu(false)}>
                      CANCEL
                    </button>
                  </div>
                </div>
              )}

              <div className="menu-grid">
                {menuItems.map((item) => (
                  <div key={item.id} className="menu-card" onClick={() => setSelectedItem(item)}>
                    {item.image && (
                      <img src={item.image || "/placeholder.svg"} alt={item.name} className="menu-card-image" />
                    )}
                    <div className="menu-card-content">
                      <h3>{item.name}</h3>
                      <p className="menu-description">{item.description}</p>
                      <p className="menu-price">₱{item.price}</p>
                      <div className="menu-actions">
                        <button className="action-btn edit" onClick={() => setSelectedItem(item)}>
                          EDIT
                        </button>
                        <button
                          className="action-btn delete"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDeleteMenuItem(item.id)
                          }}
                        >
                          DELETE
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Product Detail View */}
          {currentView === "menu" && selectedItem && (
            <section className="detail-modal">
              <div className="detail-panel">
                <div className="detail-image-section">
                  {selectedItem.image && (
                    <img
                      src={selectedItem.image || "/placeholder.svg"}
                      alt={selectedItem.name}
                      className="detail-image"
                    />
                  )}
                  <button className="detail-button">CHANGE PHOTO</button>
                  <button className="detail-button">CHANGE PRICE</button>
                </div>
                <div className="detail-form">
                  <label className="form-label">NAME:</label>
                  <input type="text" className="form-input" defaultValue={selectedItem.name} />
                  <label className="form-label">PRICE:</label>
                  <input type="text" className="form-input" defaultValue={selectedItem.price} />
                  <button className="action-btn done">DONE</button>
                </div>
              </div>
              <button className="close-modal" onClick={() => setSelectedItem(null)}>
                ✕
              </button>
            </section>
          )}

          {currentView === "drinkWheel" && (
            <section className="view-section">
              <div className="drink-wheel-container">
                <svg viewBox="0 0 200 200" className="drink-wheel">
                  <circle cx="100" cy="100" r="80" fill="none" stroke="#999" strokeWidth="2" />
                </svg>
                <div className="drinks-list">
                  <div className="drinks-header">
                    <label className="drinks-label">DRINKS:</label>
                    <button className="action-btn add" onClick={() => setShowAddDrink(true)}>
                      + ADD
                    </button>
                  </div>

                  {showAddDrink && (
                    <div className="add-drink-form">
                      <input
                        type="text"
                        placeholder="Enter drink name"
                        className="form-input"
                        value={newDrink}
                        onChange={(e) => setNewDrink(e.target.value)}
                      />
                      <div className="form-actions">
                        <button className="action-btn done" onClick={handleAddDrinkWheel}>
                          ADD
                        </button>
                        <button className="action-btn cancel" onClick={() => setShowAddDrink(false)}>
                          CANCEL
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="drinks-box">
                    {drinkWheelItems.map((drink) => (
                      <div key={drink.id} className="drink-item-with-delete">
                        <span>{drink.name}</span>
                        <button
                          className="drink-delete-btn"
                          onClick={() => handleRemoveDrink(drink.id)}
                          title="Remove drink"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <button className="action-btn done">DONE</button>
            </section>
          )}

          {/* Trend View */}
          {currentView === "trend" && (
            <section className="view-section">
              <h2 className="view-title">DRINK TREND THIS WEEK</h2>
              <table className="trend-table">
                <thead>
                  <tr>
                    <th>TIMES ORDERED</th>
                    <th>ITEM CODE</th>
                    <th>TOTAL AMOUNT</th>
                  </tr>
                </thead>
                <tbody>
                  {trendData.map((trend) => (
                    <tr key={trend.id}>
                      <td>{trend.timesOrdered}</td>
                      <td>{trend.itemCode}</td>
                      <td>₱{trend.totalAmount}.00</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button className="action-btn okay">OKAY</button>
            </section>
          )}

          {currentView === "bookings" && (
            <section className="view-section">
              <h2 className="view-title">CUSTOMER BOOKINGS:</h2>
              <div className="bookings-list">
                {bookings.map((booking) => (
                  <div key={booking.id} className="booking-card">
                    <div className="booking-header">
                      <span className="booking-label">CUSTOMER NAME</span>
                      <span className="booking-label">BOOKING</span>
                    </div>
                    <div className="booking-content">
                      <div className="booking-info">
                        <p className="booking-name">{booking.customerName}</p>
                        <p className="booking-date">DATE: {booking.date}</p>
                        <p className="booking-time">TIME: {booking.time}</p>
                      </div>
                      <div className="booking-notes">
                        <p>{booking.notes}</p>
                      </div>
                    </div>
                    <div className="booking-actions">
                      <button
                        className="action-btn approve"
                        onClick={() => handleApproveBooking(booking.id)}
                        title="Approve booking"
                      >
                        APPROVE
                      </button>
                      <button
                        className="close-booking"
                        onClick={() => handleCancelBooking(booking.id)}
                        title="Cancel booking"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {currentView === "trending" && (
            <section className="view-section">
              <h2 className="view-title">TOP 5 PRODUCTS THIS WEEK:</h2>
              <table className="trending-table">
                <thead>
                  <tr>
                    <th>ITEM:</th>
                    <th>UNIT SALES:</th>
                    <th>TOTAL:</th>
                  </tr>
                </thead>
                <tbody>
                  {trendData.slice(0, 5).map((item) => (
                    <tr key={item.id}>
                      <td>{item.itemName || item.itemCode}</td>
                      <td>{item.unitSales || 0}</td>
                      <td>₱{item.totalAmount || 0}.00</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <button className="action-btn trendline">TREND LINE</button>
            </section>
          )}
        </main>
      </div>
    </div>
  )
}
