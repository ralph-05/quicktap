"use client"

import { useState, useEffect } from "react"
import { getFirebaseDb } from "@/lib/firebase"
import { collection, onSnapshot, query } from "firebase/firestore"
import "../admin-dashboard.css"

interface Product {
  id: string
  name: string
  price: number
  description: string
  category: string
  image?: string
}

interface Category {
  id: string
  name: string
  order: number
}

export default function CustomerMenu() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [cart, setCart] = useState<{ id: string; name: string; price: number; quantity: number }[]>([])
  const [showCart, setShowCart] = useState(false)

  useEffect(() => {
    const db = getFirebaseDb()
    if (!db) {
      setLoading(false)
      return
    }

    try {
      const productsQuery = query(collection(db, "Products"))
      const unsubscribeProducts = onSnapshot(
        productsQuery,
        (snapshot) => {
          const productsData = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Product[]
          setProducts(productsData)
        },
        (error) => {
          console.error("[v0] Error fetching products:", error)
        },
      )

      const categoriesQuery = query(collection(db, "Categories"))
      const unsubscribeCategories = onSnapshot(
        categoriesQuery,
        (snapshot) => {
          const categoriesData = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Category[]
          const sorted = categoriesData.sort((a, b) => a.order - b.order)
          setCategories(sorted)
          if (sorted.length > 0 && !selectedCategory) {
            setSelectedCategory(sorted[0].name)
          }
          setLoading(false)
        },
        (error) => {
          console.error("[v0] Error fetching categories:", error)
          setLoading(false)
        },
      )

      return () => {
        unsubscribeProducts()
        unsubscribeCategories()
      }
    } catch (error) {
      console.error("Error fetching data:", error)
      setLoading(false)
    }
  }, [])

  const filteredProducts = selectedCategory ? products.filter((p) => p.category === selectedCategory) : products

  const addToCart = (product: Product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === product.id)
      if (existingItem) {
        return prevCart.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item))
      }
      return [...prevCart, { id: product.id, name: product.name, price: product.price, quantity: 1 }]
    })
  }

  const removeFromCart = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== productId))
  }

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId)
    } else {
      setCart((prevCart) => prevCart.map((item) => (item.id === productId ? { ...item, quantity } : item)))
    }
  }

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  if (loading) {
    return (
      <div className="admin-dashboard">
        <header className="admin-header">
          <h1>TORI CAFETERIA - MENU</h1>
        </header>
        <div style={{ padding: "40px", textAlign: "center" }}>
          <p>Loading menu...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="admin-dashboard">
      <header className="admin-header">
        <div style={{ flex: 1, textAlign: "center" }}>
          <h1>TORI CAFETERIA - CUSTOMER MENU</h1>
        </div>
        <button
          onClick={() => setShowCart(!showCart)}
          style={{
            background: "none",
            border: "none",
            color: "white",
            fontSize: "1.5rem",
            cursor: "pointer",
            position: "relative",
            padding: "0.5rem",
          }}
        >
          🛒
          {cartCount > 0 && (
            <span
              style={{
                position: "absolute",
                top: "0",
                right: "0",
                background: "red",
                color: "white",
                borderRadius: "50%",
                width: "24px",
                height: "24px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "0.75rem",
                fontWeight: "bold",
              }}
            >
              {cartCount}
            </span>
          )}
        </button>
      </header>

      <div style={{ display: "flex", flex: 1 }}>
        <div style={{ flex: 1, padding: "20px" }}>
          <div className="menu-header">
            <div className="category-tabs">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  className={`category-tab ${selectedCategory === cat.name ? "active" : ""}`}
                  onClick={() => setSelectedCategory(cat.name)}
                >
                  {cat.name.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          <div className="menu-grid">
            {filteredProducts.length > 0 ? (
              filteredProducts.map((product) => (
                <div key={product.id} className="menu-card">
                  <img src={product.image || "/placeholder.svg"} alt={product.name} className="menu-card-image" />
                  <div className="menu-card-content">
                    <h3>{product.name}</h3>
                    <p className="menu-description">{product.description}</p>
                    <p className="menu-price">₱{product.price.toFixed(2)}</p>
                    <button
                      className="action-btn add"
                      onClick={() => addToCart(product)}
                      style={{ background: "#6b8cc4", color: "white" }}
                    >
                      ADD TO CART
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div style={{ gridColumn: "1 / -1", textAlign: "center", padding: "20px" }}>
                <p>No products available in this category</p>
              </div>
            )}
          </div>
        </div>

        {showCart && (
          <div
            style={{
              width: "350px",
              background: "#f5f1e8",
              borderLeft: "2px solid #cccccc",
              padding: "20px",
              display: "flex",
              flexDirection: "column",
              maxHeight: "100vh",
              overflowY: "auto",
            }}
          >
            <h3 style={{ marginBottom: "1rem", fontWeight: "bold", color: "#3d2817" }}>YOUR CART</h3>

            {cart.length === 0 ? (
              <p style={{ color: "#7a7a7a", textAlign: "center", marginTop: "2rem" }}>Cart is empty</p>
            ) : (
              <>
                <div style={{ flex: 1, marginBottom: "1rem" }}>
                  {cart.map((item) => (
                    <div
                      key={item.id}
                      style={{
                        background: "white",
                        padding: "1rem",
                        marginBottom: "0.75rem",
                        borderRadius: "8px",
                        border: "1px solid #cccccc",
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
                        <span style={{ fontWeight: "bold" }}>{item.name}</span>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          style={{
                            background: "none",
                            border: "none",
                            color: "red",
                            cursor: "pointer",
                            fontSize: "1.2rem",
                          }}
                        >
                          ✕
                        </button>
                      </div>
                      <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          style={{
                            background: "#ddd",
                            border: "none",
                            padding: "0.25rem 0.5rem",
                            cursor: "pointer",
                            borderRadius: "4px",
                          }}
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value) || 1)}
                          style={{
                            width: "50px",
                            padding: "0.25rem",
                            textAlign: "center",
                            border: "1px solid #ccc",
                            borderRadius: "4px",
                          }}
                        />
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          style={{
                            background: "#ddd",
                            border: "none",
                            padding: "0.25rem 0.5rem",
                            cursor: "pointer",
                            borderRadius: "4px",
                          }}
                        >
                          +
                        </button>
                      </div>
                      <div style={{ marginTop: "0.5rem", textAlign: "right", fontWeight: "bold" }}>
                        ₱{(item.price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>

                <div
                  style={{
                    borderTop: "2px solid #cccccc",
                    paddingTop: "1rem",
                    marginTop: "1rem",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginBottom: "1rem",
                      fontWeight: "bold",
                    }}
                  >
                    <span>TOTAL:</span>
                    <span style={{ color: "#6b8cc4", fontSize: "1.2rem" }}>₱{cartTotal.toFixed(2)}</span>
                  </div>
                  <button
                    style={{
                      width: "100%",
                      padding: "0.75rem",
                      background: "#6b8cc4",
                      color: "white",
                      border: "none",
                      borderRadius: "8px",
                      fontWeight: "bold",
                      cursor: "pointer",
                    }}
                  >
                    CHECKOUT
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
