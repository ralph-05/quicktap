"use client"

import { useState, useEffect } from "react"
import { getFirebaseDb } from "@/lib/firebase"
import { collection, onSnapshot, query } from "firebase/firestore"
import "../admin-dashboard.css"

interface Product {
  id: string
  name: string
  price: number
  description: string
  category: string
  image?: string
}

interface Category {
  id: string
  name: string
  order: number
}

export default function MenuPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const db = getFirebaseDb()
    if (!db) {
      setLoading(false)
      return
    }

    try {
      const productsQuery = query(collection(db, "Products"))
      const unsubscribeProducts = onSnapshot(
        productsQuery,
        (snapshot) => {
          const items = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Product[]
          setProducts(items)
        },
        (error) => {
          console.error("[v0] Error fetching products:", error)
        },
      )

      const categoriesQuery = query(collection(db, "Categories"))
      const unsubscribeCategories = onSnapshot(
        categoriesQuery,
        (snapshot) => {
          const cats = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Category[]
          const sortedCats = cats.sort((a, b) => a.order - b.order)
          setCategories(sortedCats)
          // Set first category as default
          if (sortedCats.length > 0 && !selectedCategory) {
            setSelectedCategory(sortedCats[0].name)
          }
          setLoading(false)
        },
        (error) => {
          console.error("[v0] Error fetching categories:", error)
          setLoading(false)
        },
      )

      return () => {
        unsubscribeProducts()
        unsubscribeCategories()
      }
    } catch (err) {
      console.error("[v0] Error setting up listeners:", err)
      setLoading(false)
    }
  }, [])

  const filteredProducts = selectedCategory ? products.filter((p) => p.category === selectedCategory) : products

  if (loading) {
    return (
      <div className="admin-dashboard">
        <header className="admin-header">
          <h1>TORI CAFETERIA - MENU</h1>
        </header>
        <div style={{ padding: "40px", textAlign: "center" }}>
          <p>Loading menu...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="admin-dashboard">
      <header className="admin-header">
        <h1>TORI CAFETERIA - MENU</h1>
      </header>

      <div style={{ padding: "20px" }}>
        <div className="menu-header">
          <div className="category-tabs">
            {categories.map((cat) => (
              <button
                key={cat.id}
                className={`category-tab ${selectedCategory === cat.name ? "active" : ""}`}
                onClick={() => setSelectedCategory(cat.name)}
              >
                {cat.name.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        <div className="menu-grid">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <div key={product.id} className="menu-card">
                <img src={product.image || "/placeholder.svg"} alt={product.name} className="menu-card-image" />
                <div className="menu-card-content">
                  <h3>{product.name}</h3>
                  <p className="menu-description">{product.description}</p>
                  <p className="menu-price">₱{product.price.toFixed(2)}</p>
                  <button className="action-btn add">ORDER NOW</button>
                </div>
              </div>
            ))
          ) : (
            <div style={{ gridColumn: "1 / -1", textAlign: "center", padding: "20px" }}>
              <p>No products available in this category</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
