"use client"

import { useState } from "react"
import ProductManagement from "@/components/product-management"
import "../admin-dashboard.css"

export default function AdminDashboard() {
  const [currentView, setCurrentView] = useState("products")

  return (
    <div className="admin-dashboard">
      <header className="admin-header">
        <h1>ADMIN DASHBOARD - MANAGEMENT</h1>
        <button className="menu-toggle">☰</button>
      </header>

      <div className="dashboard-container">
        <aside className="admin-sidebar">
          <nav className="sidebar-nav">
            <button
              className={`nav-button ${currentView === "products" ? "active" : ""}`}
              onClick={() => setCurrentView("products")}
            >
              MANAGE PRODUCTS
            </button>
            <button
              className={`nav-button ${currentView === "orders" ? "active" : ""}`}
              onClick={() => setCurrentView("orders")}
            >
              MANAGE ORDERS
            </button>
            <button
              className={`nav-button ${currentView === "analytics" ? "active" : ""}`}
              onClick={() => setCurrentView("analytics")}
            >
              VIEW ANALYTICS
            </button>
          </nav>
        </aside>

        <main className="admin-main">
          {currentView === "products" && (
            <section className="view-section">
              <h2 className="view-title">PRODUCTS & CATEGORIES MANAGEMENT</h2>
              <ProductManagement />
            </section>
          )}

          {currentView === "orders" && (
            <section className="view-section">
              <h2 className="view-title">ORDERS MANAGEMENT</h2>
              <div className="bg-white p-6 rounded border border-gray-300">
                <p className="text-gray-600">Order management feature coming soon...</p>
              </div>
            </section>
          )}

          {currentView === "analytics" && (
            <section className="view-section">
              <h2 className="view-title">SALES ANALYTICS</h2>
              <div className="bg-white p-6 rounded border border-gray-300">
                <p className="text-gray-600">Analytics feature coming soon...</p>
              </div>
            </section>
          )}
        </main>
      </div>
    </div>
  )
}
