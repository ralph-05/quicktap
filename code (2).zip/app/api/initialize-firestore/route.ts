import { NextResponse } from "next/server"
import { getFirebaseDb, getFirebaseAuth } from "@/lib/firebase"
import { collection, getDocs, setDoc, doc } from "firebase/firestore"

export async function GET() {
  try {
    const db = getFirebaseDb()
    const auth = getFirebaseAuth()

    if (!db || !auth) {
      return NextResponse.json({ error: "Firebase not initialized" }, { status: 500 })
    }

    // Check if collections exist, if not create them with sample data
    const categoriesRef = collection(db, "Categories")
    const productsRef = collection(db, "Products")

    const categoriesSnapshot = await getDocs(categoriesRef)
    const productsSnapshot = await getDocs(productsRef)

    // Initialize Categories if empty
    const defaultCategories = [
      { id: "coffee", name: "Coffee", order: 1 },
      { id: "non-coffee", name: "Non-Coffee", order: 2 },
      { id: "frappe", name: "Frappe", order: 3 },
      { id: "soda", name: "Soda", order: 4 },
      { id: "pastries", name: "Pastries", order: 5 },
    ]

    if (categoriesSnapshot.empty) {
      for (const category of defaultCategories) {
        await setDoc(doc(categoriesRef, category.id), {
          name: category.name,
          order: category.order,
          createdAt: new Date(),
        })
      }
    }

    // Initialize Products if empty
    const defaultProducts = [
      {
        name: "Espresso",
        price: 85,
        description: "Strong and bold espresso shot",
        category: "coffee",
        image: "/espresso-shot.png",
        createdAt: new Date(),
      },
      {
        name: "Cappuccino",
        price: 120,
        description: "Espresso with steamed milk and foam",
        category: "coffee",
        image: "/frothy-cappuccino.png",
        createdAt: new Date(),
      },
      {
        name: "Iced Latte",
        price: 130,
        description: "Cold latte with ice",
        category: "coffee",
        image: "/iced-latte.jpg",
        createdAt: new Date(),
      },
      {
        name: "Strawberry Frappe",
        price: 140,
        description: "Chilled strawberry blended drink",
        category: "frappe",
        image: "/strawberry-frappe.jpg",
        createdAt: new Date(),
      },
      {
        name: "Sprite",
        price: 60,
        description: "Lemon-lime flavored soda",
        category: "soda",
        image: "/sparkling-sprite.png",
        createdAt: new Date(),
      },
      {
        name: "Chocolate Croissant",
        price: 95,
        description: "Buttery croissant with chocolate filling",
        category: "pastries",
        image: "/chocolate-croissant.jpg",
        createdAt: new Date(),
      },
    ]

    if (productsSnapshot.empty) {
      for (const product of defaultProducts) {
        await setDoc(doc(productsRef), product)
      }
    }

    return NextResponse.json({
      message: "Firestore initialized successfully",
      categoriesCount: categoriesSnapshot.docs.length || defaultCategories.length,
      productsCount: productsSnapshot.docs.length || defaultProducts.length,
    })
  } catch (error) {
    console.error("[v0] Firestore initialization error:", error)
    return NextResponse.json({ error: "Failed to initialize Firestore" }, { status: 500 })
  }
}
