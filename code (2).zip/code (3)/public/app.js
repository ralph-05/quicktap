// Import Firebase modules
import firebase from "firebase/app"
import "firebase/firestore"

// Firebase Configuration - Replace with your actual values
const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY || "AIzaSyD...",
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN || "your-project.firebaseapp.com",
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID || "your-project",
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET || "your-project.appspot.com",
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: process.env.REACT_APP_FIREBASE_APP_ID || "1:123456789:web:abc123def456",
}

// Initialize Firebase
firebase.initializeApp(firebaseConfig)
const db = firebase.firestore()

// Get menu items from Firestore
async function loadMenu() {
  try {
    const menuContent = document.getElementById("menuContent")
    menuContent.innerHTML = '<div class="loading">Loading menu...</div>'

    const querySnapshot = await db.collection("Products").get()
    const products = []

    querySnapshot.forEach((doc) => {
      products.push({
        id: doc.id,
        ...doc.data(),
      })
    })

    displayMenu(products)
  } catch (error) {
    console.error("Error loading menu:", error)
    document.getElementById("menuContent").innerHTML =
      '<div class="error">Error loading menu. Please refresh the page.</div>'
  }
}

// Display menu items
function displayMenu(products) {
  const menuContent = document.getElementById("menuContent")
  const selectedCategory = document.getElementById("categoryFilter").value

  const filteredProducts =
    selectedCategory === "all" ? products : products.filter((p) => p.category === selectedCategory)

  if (filteredProducts.length === 0) {
    menuContent.innerHTML = '<div class="no-items">No items in this category</div>'
    return
  }

  menuContent.innerHTML = filteredProducts
    .map(
      (product) => `
    <div class="product-card">
      <h3>${product.name}</h3>
      <p class="price">₱${product.price}</p>
      ${product.size ? `<p class="size">${product.size}</p>` : ""}
    </div>
  `,
    )
    .join("")
}

// Event listener for category filter
document.getElementById("categoryFilter").addEventListener("change", () => {
  loadMenu()
})

// Load menu on page load
document.addEventListener("DOMContentLoaded", loadMenu)
