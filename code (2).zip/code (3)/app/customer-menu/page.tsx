"use client"

import { useState, useEffect } from "react"
import { db } from "@/lib/firebase"
import { collection, getDocs } from "firebase/firestore"
import "../admin-dashboard.css"

export default function CustomerMenu() {
  const [products, setProducts] = useState([])
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "Products"))
        const productsData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }))
        setProducts(productsData)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching products:", error)
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  const filteredProducts =
    selectedCategory === "all" ? products : products.filter((p) => p.category === selectedCategory)

  return (
    <div className="admin-dashboard">
      <div className="header">
        <h1>Tori Cafeteria Menu</h1>
      </div>

      <div className="menu-container">
        <div className="filter-section">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="category-select"
          >
            <option value="all">All Categories</option>
            <option value="coffee">Coffee</option>
            <option value="non-coffee">Non-Coffee</option>
            <option value="frappe">Frappe</option>
            <option value="soda">Soda</option>
            <option value="pastries">Pastries</option>
          </select>
        </div>

        {loading ? (
          <div className="loading">Loading menu...</div>
        ) : (
          <div className="products-grid">
            {filteredProducts.map((product) => (
              <div key={product.id} className="product-card">
                <h3>{product.name}</h3>
                <p className="price">₱{product.price}</p>
                {product.size && <p className="size">{product.size}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
