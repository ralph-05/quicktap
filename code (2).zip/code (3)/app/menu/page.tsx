"use client"

import { ProtectedRoute } from "@/components/protected-route"
import { useState, useEffect } from "react"
import { getFirebaseDb } from "@/lib/firebase"
import { collection, onSnapshot, query } from "firebase/firestore"
import "../admin-dashboard.css"

export default function MenuPage() {
  const [products, setProducts] = useState([])
  const [selectedCategory, setSelectedCategory] = useState("ALL")

  useEffect(() => {
    const db = getFirebaseDb()
    if (!db) return

    const menuQuery = query(collection(db, "menuItems"))
    const unsubscribe = onSnapshot(menuQuery, (snapshot) => {
      const items = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
      setProducts(items)
    })

    return () => unsubscribe()
  }, [])

  const filteredProducts =
    selectedCategory === "ALL" ? products : products.filter((p) => p.category === selectedCategory)

  return (
    <ProtectedRoute>
      <div className="admin-dashboard">
        <header className="admin-header">
          <h1>TORI CAFETERIA - MENU</h1>
        </header>

        <div style={{ padding: "20px" }}>
          <div className="menu-header">
            <div className="category-tabs">
              {["ALL", "COFFEE", "PASTRY", "BEVERAGE"].map((cat) => (
                <button
                  key={cat}
                  className={`category-tab ${selectedCategory === cat ? "active" : ""}`}
                  onClick={() => setSelectedCategory(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="menu-grid">
            {filteredProducts.map((product) => (
              <div key={product.id} className="menu-card">
                <img src={product.image || "/placeholder.svg"} alt={product.name} className="menu-card-image" />
                <div className="menu-card-content">
                  <h3>{product.name}</h3>
                  <p className="menu-description">{product.description}</p>
                  <p className="menu-price">₱{product.price}</p>
                  <button className="action-btn add">ORDER NOW</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}
