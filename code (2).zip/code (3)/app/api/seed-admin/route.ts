import { createUserWithEmailAndPassword } from "firebase/auth"
import { getFirebaseAuth, getFirebaseDb } from "@/lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { NextResponse } from "next/server"

export async function POST() {
  try {
    const auth = getFirebaseAuth()
    const db = getFirebaseDb()

    if (!auth || !db) {
      return NextResponse.json({ error: "Firebase not initialized" }, { status: 500 })
    }

    // Create admin account
    const userCredential = await createUserWithEmailAndPassword(auth, "admin@cafeteria.com", "Admin@123")

    // Save admin profile to Firestore
    await addDoc(collection(db, "users"), {
      uid: userCredential.user.uid,
      email: "admin@cafeteria.com",
      fullName: "Admin User",
      role: "admin",
      createdAt: new Date(),
    })

    return NextResponse.json({
      success: true,
      message: "Admin account created",
      email: "admin@cafeteria.com",
      password: "Admin@123",
    })
  } catch (error: any) {
    console.log("[v0] Seed error:", error.message)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
