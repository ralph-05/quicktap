"use client"

import { ProtectedRoute } from "@/components/protected-route"
import AdminDashboard from "../admin-dashboard-component"

export default function DashboardPage() {
  return (
    <ProtectedRoute requiredRole="admin">
      <AdminDashboard />
    </ProtectedRoute>
  )
}
