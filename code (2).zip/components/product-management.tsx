"use client"

import { useState, useEffect } from "react"
import { getFirebaseDb } from "@/lib/firebase"
import { collection, onSnapshot, query, addDoc, updateDoc, deleteDoc, doc } from "firebase/firestore"

interface Product {
  id: string
  name: string
  price: number
  description: string
  category: string
  image?: string
  createdAt?: Date
}

interface Category {
  id: string
  name: string
  order: number
}

export default function ProductManagement() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedTab, setSelectedTab] = useState<"products" | "categories">("products")
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  // Product form state
  const [productForm, setProductForm] = useState({
    name: "",
    price: "",
    description: "",
    category: "",
    image: "",
  })

  // Category form state
  const [categoryForm, setCategoryForm] = useState({
    name: "",
    order: "",
  })

  useEffect(() => {
    const db = getFirebaseDb()
    if (!db) {
      setError("Firebase not initialized")
      setLoading(false)
      return
    }

    try {
      const productsQuery = query(collection(db, "Products"))
      const unsubscribeProducts = onSnapshot(
        productsQuery,
        (snapshot) => {
          const productsData = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Product[]
          setProducts(productsData)
        },
        (err) => {
          console.error("[v0] Error fetching products:", err)
          setError("Failed to load products")
        },
      )

      const categoriesQuery = query(collection(db, "Categories"))
      const unsubscribeCategories = onSnapshot(
        categoriesQuery,
        (snapshot) => {
          const categoriesData = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Category[]
          setCategories(categoriesData.sort((a, b) => a.order - b.order))
          setLoading(false)
        },
        (err) => {
          console.error("[v0] Error fetching categories:", err)
          setError("Failed to load categories")
          setLoading(false)
        },
      )

      return () => {
        unsubscribeProducts()
        unsubscribeCategories()
      }
    } catch (err) {
      console.error("[v0] Setup error:", err)
      setError("Failed to initialize")
      setLoading(false)
    }
  }, [])

  const handleAddProduct = async () => {
    if (!productForm.name || !productForm.price || !productForm.category) {
      alert("Please fill in required fields: name, price, category")
      return
    }

    try {
      const db = getFirebaseDb()
      if (!db) return

      if (editingId) {
        await updateDoc(doc(db, "Products", editingId), {
          name: productForm.name,
          price: Number.parseFloat(productForm.price),
          description: productForm.description,
          category: productForm.category,
          image: productForm.image || "/placeholder.svg",
        })
        setEditingId(null)
      } else {
        await addDoc(collection(db, "Products"), {
          name: productForm.name,
          price: Number.parseFloat(productForm.price),
          description: productForm.description,
          category: productForm.category,
          image: productForm.image || "/placeholder.svg",
          createdAt: new Date(),
        })
      }

      setProductForm({ name: "", price: "", description: "", category: "", image: "" })
      setShowAddForm(false)
    } catch (err) {
      console.error("[v0] Error saving product:", err)
      alert("Failed to save product")
    }
  }

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Are you sure you want to delete this product?")) return

    try {
      const db = getFirebaseDb()
      if (db) {
        await deleteDoc(doc(db, "Products", id))
      }
    } catch (err) {
      console.error("[v0] Error deleting product:", err)
      alert("Failed to delete product")
    }
  }

  const handleEditProduct = (product: Product) => {
    setProductForm({
      name: product.name,
      price: product.price.toString(),
      description: product.description,
      category: product.category,
      image: product.image || "",
    })
    setEditingId(product.id)
    setShowAddForm(true)
  }

  const handleAddCategory = async () => {
    if (!categoryForm.name || !categoryForm.order) {
      alert("Please fill in category name and order")
      return
    }

    try {
      const db = getFirebaseDb()
      if (!db) return

      const categoryId = categoryForm.name.toLowerCase().replace(/\s+/g, "-")

      if (editingId) {
        await updateDoc(doc(db, "Categories", editingId), {
          name: categoryForm.name,
          order: Number.parseInt(categoryForm.order),
        })
        setEditingId(null)
      } else {
        await addDoc(collection(db, "Categories"), {
          name: categoryForm.name,
          order: Number.parseInt(categoryForm.order),
          createdAt: new Date(),
        })
      }

      setCategoryForm({ name: "", order: "" })
      setShowAddForm(false)
    } catch (err) {
      console.error("[v0] Error saving category:", err)
      alert("Failed to save category")
    }
  }

  const handleDeleteCategory = async (id: string) => {
    if (!confirm("Are you sure? This will not delete products in this category.")) return

    try {
      const db = getFirebaseDb()
      if (db) {
        await deleteDoc(doc(db, "Categories", id))
      }
    } catch (err) {
      console.error("[v0] Error deleting category:", err)
      alert("Failed to delete category")
    }
  }

  const handleEditCategory = (category: Category) => {
    setCategoryForm({
      name: category.name,
      order: category.order.toString(),
    })
    setEditingId(category.id)
    setShowAddForm(true)
  }

  if (loading) {
    return <div className="p-8 text-center">Loading...</div>
  }

  return (
    <div className="space-y-6">
      {error && <div className="bg-red-100 text-red-800 p-4 rounded">{error}</div>}

      {/* Tabs */}
      <div className="flex gap-2 border-b">
        <button
          onClick={() => setSelectedTab("products")}
          className={`px-4 py-2 font-semibold border-b-2 transition ${
            selectedTab === "products"
              ? "border-blue-500 text-blue-600"
              : "border-transparent text-gray-600 hover:text-gray-800"
          }`}
        >
          Products ({products.length})
        </button>
        <button
          onClick={() => setSelectedTab("categories")}
          className={`px-4 py-2 font-semibold border-b-2 transition ${
            selectedTab === "categories"
              ? "border-blue-500 text-blue-600"
              : "border-transparent text-gray-600 hover:text-gray-800"
          }`}
        >
          Categories ({categories.length})
        </button>
      </div>

      {/* Products Tab */}
      {selectedTab === "products" && (
        <div className="space-y-4">
          <button
            onClick={() => {
              setShowAddForm(!showAddForm)
              setEditingId(null)
              setProductForm({ name: "", price: "", description: "", category: "", image: "" })
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 font-semibold"
          >
            {showAddForm ? "Cancel" : "+ Add Product"}
          </button>

          {showAddForm && (
            <div className="bg-white p-6 rounded border border-gray-300">
              <h3 className="font-semibold mb-4">{editingId ? "Edit Product" : "Add New Product"}</h3>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Product Name"
                  value={productForm.name}
                  onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded"
                />
                <input
                  type="number"
                  placeholder="Price"
                  value={productForm.price}
                  onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded"
                />
                <input
                  type="text"
                  placeholder="Description"
                  value={productForm.description}
                  onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded"
                />
                <select
                  value={productForm.category}
                  onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded"
                >
                  <option value="">Select Category</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.name}>
                      {cat.name}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  placeholder="Image URL (optional)"
                  value={productForm.image}
                  onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded"
                />
                <button
                  onClick={handleAddProduct}
                  className="w-full bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 font-semibold"
                >
                  {editingId ? "Update Product" : "Add Product"}
                </button>
              </div>
            </div>
          )}

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => (
              <div key={product.id} className="bg-white p-4 rounded border border-gray-300">
                {product.image && (
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-40 object-cover rounded mb-3"
                  />
                )}
                <h4 className="font-semibold text-lg mb-1">{product.name}</h4>
                <p className="text-sm text-gray-600 mb-2">{product.description}</p>
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-blue-600">₱{product.price.toFixed(2)}</span>
                  <span className="text-xs bg-gray-200 px-2 py-1 rounded">{product.category}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEditProduct(product)}
                    className="flex-1 bg-blue-500 text-white px-2 py-1 rounded text-sm hover:bg-blue-600"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteProduct(product.id)}
                    className="flex-1 bg-red-500 text-white px-2 py-1 rounded text-sm hover:bg-red-600"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Categories Tab */}
      {selectedTab === "categories" && (
        <div className="space-y-4">
          <button
            onClick={() => {
              setShowAddForm(!showAddForm)
              setEditingId(null)
              setCategoryForm({ name: "", order: "" })
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 font-semibold"
          >
            {showAddForm ? "Cancel" : "+ Add Category"}
          </button>

          {showAddForm && (
            <div className="bg-white p-6 rounded border border-gray-300">
              <h3 className="font-semibold mb-4">{editingId ? "Edit Category" : "Add New Category"}</h3>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Category Name"
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded"
                />
                <input
                  type="number"
                  placeholder="Display Order (1, 2, 3...)"
                  value={categoryForm.order}
                  onChange={(e) => setCategoryForm({ ...categoryForm, order: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded"
                />
                <button
                  onClick={handleAddCategory}
                  className="w-full bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 font-semibold"
                >
                  {editingId ? "Update Category" : "Add Category"}
                </button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {categories.map((category) => (
              <div
                key={category.id}
                className="bg-white p-4 rounded border border-gray-300 flex justify-between items-center"
              >
                <div>
                  <h4 className="font-semibold">{category.name}</h4>
                  <p className="text-sm text-gray-600">Order: {category.order}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEditCategory(category)}
                    className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteCategory(category.id)}
                    className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
